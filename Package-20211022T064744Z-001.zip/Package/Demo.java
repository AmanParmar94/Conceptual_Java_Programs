package Marvellous.Python;

public class Demo
{
	public void fun()
	{
		System.out.println("Inside fun");
	}
}