package Marvellous.PPA;

public class Mathematics
{
	public int Add(int no1, int no2)
	{
		System.out.println("Inside Add");
		return no1 + no2;
	}
}